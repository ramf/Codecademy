=begin

Getting the User's Input

First things first: we'll need to get the user's input.
Instructions

Use puts to prompt the user for input two times. For the first puts, declare a variable called text and set it equal to the user's input via gets.chomp. For the second puts, declare a variable called redact and set it equal to the user's input using gets.chomp.
=end
puts "first prompt"
text = gets.chomp

puts "2nd prompt"
redact = gets.chomp