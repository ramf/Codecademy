#!/usr/bin/env ruby

=begin
Sometimes you do know how many times you'll be looping, 
however, and when that's the case, you'll want to use a for loop.
=end

for num in 1...10 # will not include the # 10!
  puts num
end