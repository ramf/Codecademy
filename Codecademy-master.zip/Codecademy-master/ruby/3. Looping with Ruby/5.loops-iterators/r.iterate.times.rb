=begin

Iterating with .times

Finally, let's replace our loop with the .times iterator.
Instructions

Use the .times iterator to print "Ruby!" to the console 30 times. Hit Save & Submit Code to see the majesty of your code and complete this lesson!
=end

30.times { 
  print "Ruby!"
}
end
