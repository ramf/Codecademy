=begin

The .times Iterator

The .times method is like a super compact for loop: it can perform a task on each item in an object a specified number of times.

For example, if we wanted to print out "Chunky bacon!" ten times, we might type

10.times { print "Chunky bacon!" }

We don't know why we would type that, but we could.
Instructions

Use the .times operator to print out a string of your choice any number of times you like. Use the code in the text above as a guide if you need help.
=end

90.times { print "#Pwn2Own" }
