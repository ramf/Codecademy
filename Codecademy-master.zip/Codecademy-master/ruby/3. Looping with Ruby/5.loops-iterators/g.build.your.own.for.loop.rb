=begin

Building Your Own

Good work! You're ready to build your very own for loop.
Write a for loop that puts the numbers 1 to 20, including 20, using either .. or .... Check Hint if you need a syntax refresher.
=end

for num in 1...21
  puts num
end