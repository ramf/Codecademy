=begin

Looping with 'While'

Okay, training wheels off. Let's see your stuff!

i = 3
while i > 0 do
  print i
  i -= 1
end

    In the above example, we create a variable called i and set it to 3.
    Then, we print out 321 since we execute the loop so long as i is positive.

Instructions

Use a while loop to print out the numbers 1 through 50, inclusive. While the example above counts down, you will want to count up.

Use print rather than puts, and don't forget to increment your variable.

Ref:
http://www.codecademy.com/forum_questions/510d0530ab55b5623d004776
http://www.rubyist.net/~slagell/ruby/index.html
=end

x = 1

while x <= 50
print x
x += 1
end