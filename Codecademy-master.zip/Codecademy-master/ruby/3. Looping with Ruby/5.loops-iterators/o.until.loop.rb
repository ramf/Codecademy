=begin

Looping with 'Until'

Good work!

i = 3
while i > 0 do
  print i
  i -= 1
end

j = 3
until j == 0 do
  print j
  i -= 1
end

In the example above, we wrote the same loop using while and using until.
Instructions

Now rewrite your while loop using until.

You still want to print out the numbers 1 through 50, inclusive.

=end
x = 1

until x == 51
print x
x += 1
end