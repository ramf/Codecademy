=begin

Arrays of Non-Numbers

Here's something you might not have known: you can make an array of any collection of Ruby objects. You can make an array of booleans! An array of strings! The list is (almost) endless.
Instructions

Create a new array called string_array. Make it an array of... strings!
=end

string_array = ["Help", "me", "now"]