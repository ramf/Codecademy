=begin

Creating Arrays

Earlier we saw that an array can be used to store a list of values in a single variable. You can stuff any number of numbers in there, you can repeat numbers, and they don't have to be in numeric order!
Instructions

Declare a variable, my_array, in the editor, and set it equal to an array of your choice. Check the Hint if you need a syntax refresher.
=end

my_array = [1, 3, 5, 7]