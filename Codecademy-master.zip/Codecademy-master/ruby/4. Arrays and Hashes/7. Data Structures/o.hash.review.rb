=begin
Good! Now let's create a hash. Feel free to use either hash literal notation or Hash.new.

prices = { 
  "apple" => 0.52,
  "banana" => 0.23,
  "kiwi" => 1.42
}

sounds = Hash.new
sounds["dog"] = "woof"
sounds["cat"] = "meow"

Instructions

    Create a hash called my_hash in the editor.
    Give it at least one key-value pair.


=end

my_hash = { 
  "dino" => 0.12,
  "banana" => 0.23,
  "kiwi" => 1.42
}
