=begin

Create Your Own

See how a two-dimensional array with the same number of elements per row and overall rows is a square? An array (like a line) is one-dimensional; an array of arrays (like a square) is two-dimensional.
Instructions

Create your own two-dimensional array called my_2d_array in the editor. The elements of the inner array can be anything you like: numbers, strings, booleans, and so on. Check the Hint if you need help.
=end

my_2d_array = [["Hi!", "$5.00"], [1, 3, "4-2"]]

# Output:
[["Hi!", "$5.00"], [1, 3, "4-2"]] 