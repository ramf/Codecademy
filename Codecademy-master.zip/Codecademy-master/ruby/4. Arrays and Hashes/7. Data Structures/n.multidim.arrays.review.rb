=begin

Multidimensional Arrays

Great work! You've learned a lot in this lesson. Let's do a little review to be sure you really know your stuff.
Instructions

Create your own multidimensional array called my_array in the editor. The elements of the innermost array can be anything you like: numbers, strings, booleans, and so on. Check the Hint if you need help.
=end

my_array = [["spider", "Deadly"], [1,3,4]]
