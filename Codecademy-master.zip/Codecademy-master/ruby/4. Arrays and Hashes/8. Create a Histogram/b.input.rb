=begin

You Know the Drill

You know by now how we've gotta start: we need to get input from the user.
Instructions

Use a puts statement to prompt the user for input. Use gets.chomp to save this input to a variable called text.
=end

puts "Enter some text" # puts statement to prompt the user for input.
text = gets.chomp      # gets.chomp to save this input to a variable called text.
