# Conditional Assignment
# Perfect! Now let's review conditional assignment. We'll take a break from strict editing mode and let you do a bit more writing.

# Instructions
# Create a variable called favorite_animal and conditionally assign it to a string containing the name of your favorite animal.

# ?
# Hint
# Remember, the conditional assignment operator is ||=.

favorite_animal = nil
puts favorite_animal

favorite_animal ||= "shark"
puts favorite_animal

