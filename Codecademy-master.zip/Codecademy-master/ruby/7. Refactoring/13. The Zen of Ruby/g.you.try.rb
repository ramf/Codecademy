=begin

Now You Try!

Now it's your turn!
Instructions

Create a variable, favorite_language, and conditionally set it to your favorite programming language.
=end

# Write your code on line 2!

puts favorite_language ||= "Ruby!"

# Output:
Ruby!
nil
