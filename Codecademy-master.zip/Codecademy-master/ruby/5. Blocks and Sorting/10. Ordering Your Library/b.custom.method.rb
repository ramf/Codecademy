=begin

Defining Our Method

First, we'll need to define our alphabetize method.
Instructions

Define alphabetize in the editor to the right. It shouldn't take any arguments yet, and there doesn't need to be anything in the body of the method.
?
Hint

Don't forget:

method_name(optional parameters)
  # Do something
end
=end

def alphabetize
end
