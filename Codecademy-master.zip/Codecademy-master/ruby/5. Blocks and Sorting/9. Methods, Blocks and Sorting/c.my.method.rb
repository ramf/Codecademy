=begin

Create Your Own

Now it's time for you to build your own method. Remember, the syntax looks like this:

def method_name
  # Do something!
end

Instructions

Create a method, greeting, in the editor. It should use puts to print a greeting to the console.
=end

# Define your method below!

def greeting
    puts "This is a simple method example!"
end

# Define your method above this line.

greeting # Ignore this for now. We'll explain
         # it in the next exercise!