#!/usr/bin/env ruby

my_name = "Rick"
my_age  = 30

=begin

Variables & Data Types

Let's quickly review how to declare and set variables. Remember, you declare a variable just by saying its name, 
and you set it using =. You can always check the Hint below if you need more help.

=end
