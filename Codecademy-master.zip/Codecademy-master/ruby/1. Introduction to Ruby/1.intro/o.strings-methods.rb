#!/usr/bin/env ruby

name = "Rick".downcase.reverse.upcase

=begin

Strings and String Methods

Well done! Let's do a little review of string methods. Remember, you call a method by using the . operator, like this: "string".method.

=end
