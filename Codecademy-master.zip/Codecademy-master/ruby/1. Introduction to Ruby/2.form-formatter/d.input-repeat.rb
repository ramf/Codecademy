#!/usr/bin/env ruby

print "Whats your first name?"
print "Whats your last name?"
print "city?"
print "state?"

first_name = gets.chomp
last_name = gets.chomp
city = gets.chomp
state = gets.chomp

print "Hi #{first_name} #{last_name}. I can see that your from #{city}, #{state}."

=begin

Repeat for More Input

All right! Now we need to repeat what we've done for last_name, city, and state.

=end
