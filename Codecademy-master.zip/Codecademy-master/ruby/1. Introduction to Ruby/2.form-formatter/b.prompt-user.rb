#!/usr/bin/env ruby

print "Whats your first name?"p

=begin

Prompting the User

First, let's write the code we're already familiar with. In order to get input from the user, 
we'll first need to print a prompt on the screen.

=end
