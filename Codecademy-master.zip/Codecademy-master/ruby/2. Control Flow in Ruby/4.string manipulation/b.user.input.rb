=begin

Getting User Input

First, we should print a statement to prompt the user for input, then set that input to a variable using gets.chomp.

=end

print "What is your name?"
user_input = gets.chomp