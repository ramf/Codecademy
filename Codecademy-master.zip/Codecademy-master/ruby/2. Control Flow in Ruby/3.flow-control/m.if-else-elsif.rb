
=begin

If, Else, and Elsif

All right! You're all on your lonesome. (Well, not quite. We'll just leave this example here.)

a = 10
b = 11
if a < b
  print "a is less than b!"
elsif b > a
  print "b is less than a!"
else
  print "b is equal to a!"
end

=end

if 3 < 4
    puts "3 is less than 4"
    elsif 3 > 4
    puts "3 is greater than 4"
else
    puts "lets try something else"
end