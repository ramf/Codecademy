#!/usr/bin/env ruby

test_1 = 17 > 16

test_2 = 21 < 30

test_3 = 9 <= 9

test_4 = -11 <= 4

=begin

Less Than or Greater Than

We can also check to see if one value is less than, less than or equal to, greater than, or greater than or equal to another. 
Those operators look like this:

    Less than: <
    Less than or equal to: <=
    Greater than: >
    Greater than or equal to: >=


=end