
=begin

Unless

Good! Now let's review the unless statement.

problem = false
print "Good to go!" unless problem

Remember, this is basically a short hand if statement. It will do whatever you ask unless the condition is true. 
In our example, problem is false, so we don't have a problem. We print Good to go!

=end

unless false
puts "i get printed"
end