
=begin

Dare to Compare

Now let's review comparators / relational operators. We've turned the tables a bit!

Remember, comparators need to compare two values to each other to result in true or false

10 > 8 // true
8 > 10 // false
8 == 10 // false
8 != 10 // true

=end

# test_1 should be false
test_1 = 5 >= 10

# test_2 = should be false
test_2 = 4.3 > 5.2

# test_3 = should be true
test_3 = 2 > 1