
=begin

Not

Finally, Ruby has the boolean operator not (!). ! makes true values false, and vice-versa.

!true # => false
!false # => true

=end

# boolean_1 = !true
boolean_1 = false

# boolean_2 = !true && !true
boolean_2 = false

# boolean_3 = !(700 / 10 == 70)
boolean_3 = false